package com.amazon.signup;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

@Controller
//@SessionAttributes("email")
public class SignupController 
{	
	@Autowired
	SignupService Service;
	
	public static String uploadDirectory = System.getProperty("user.dir")+"/Amazon_uploads";
	
	@RequestMapping(value="/RegistrationPage", method=RequestMethod.GET)
	public String showSignupPage()
	{
		return "RegistrationPage";
	}
	
	@RequestMapping(value="/RegistrationPage" , method=RequestMethod.POST)
	public String handleSignupData(ModelMap model,@RequestParam String name,@RequestParam long phone_number,@RequestParam String email,@RequestParam String password,@RequestParam String city,@RequestParam String gender,@RequestParam String status,HttpSession session)
	{ 
		/*// type of user - customer or manager or both
		System.out.println(photo);
		
		if(Service.checkUserExistance(email))
		{
			System.out.println("no");
			model.put("errorMessage","User Exits ! Try another E-mail Id.");
			return "RegistrationPage";
		}
		else
		{
			System.out.println("yes");
			
			
			 * String url = request.getRequestURL().toString(); String baseUrl =
			 * url.substring(0, url.length() - request.getRequestURI().length()) +
			 * request.getContextPath() + "/";
			 
			 Path fn=Paths.get(uploadDirectory,photo.getOriginalFilename()); 
			 String filename=photo.getOriginalFilename();
			 System.out.println(fn);
			 			
			//System.out.println(fn.toString().equals("C:\\SpringToolSuite-Workspace\\UpdatedAmazonWebApp - Copy\\Amazon_uploads"));
			
			if(!fn.toString().equals("C:\\Users\\MANIKYA\\Documents\\workspace-spring-tool-suite-4-4.1.1.RELEASE\\equarth\\Amazon_uploads"))
			{
				try 
				{
					Files.write(fn, photo.getBytes());
				} 
				catch (IOException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			System.out.println(filename);
			//System.out.println(name+"\n"+phone_number+"\n"+email+"\n"+password+"\n"+city+"\n\n"+gender);
			 * 
*/			
		/*String path=session.getServletContext().getRealPath("/");  
        String filename=photo.getOriginalFilename();  
          
        System.out.println(path+"resources\\images\\   "+filename);  
        try{  
        byte barr[]=photo.getBytes();  
          
        BufferedOutputStream bout=new BufferedOutputStream(  
                 new FileOutputStream(path+"resources\\images\\"+filename));  
        bout.write(barr);  
        bout.flush();  
        bout.close(); */ 
          
       // }catch(Exception e){System.out.println(e);}
		Service.addUser(name,phone_number,email,password,city,gender,status);
		model.clear();
		model.put("email", email);
			return "redirect:/events";
		}
	}
